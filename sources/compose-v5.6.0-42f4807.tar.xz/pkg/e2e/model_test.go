//go:build e2e

/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package e2e

import (
	"testing"
)

func TestComposeModel(t *testing.T) {
	if _, err := findPluginExecutable(DockerModelExecutableName); err != nil {
		t.Skip("docker-model plugin not available")
	}
	NewScenario(t, "a service bound to a model must receive the model runner's URL").
		Step("the service can reach the model endpoint variable",
			ComposeCmd("run", "--rm", "test", "sh", "-c", "curl ${FOO_URL}"))
}
