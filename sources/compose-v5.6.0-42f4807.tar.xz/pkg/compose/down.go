/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package compose

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/compose-spec/compose-go/v2/types"
	"github.com/containerd/errdefs"
	containerType "github.com/moby/moby/api/types/container"
	"github.com/moby/moby/api/types/image"
	"github.com/moby/moby/client"
	"github.com/sirupsen/logrus"
	"golang.org/x/sync/errgroup"
	"golang.org/x/sync/semaphore"

	"github.com/docker/compose/v5/pkg/api"
	"github.com/docker/compose/v5/pkg/utils"
)

type downOp func() error

func (s *composeService) Down(ctx context.Context, projectName string, options api.DownOptions) error {
	return Run(ctx, func(ctx context.Context) error {
		return s.down(ctx, strings.ToLower(projectName), options)
	}, "down", s.events)
}

func (s *composeService) down(ctx context.Context, projectName string, options api.DownOptions) error {
	resourceToRemove := false

	include := oneOffExclude
	if options.RemoveOrphans {
		// down stops the application: one-off containers — RUNNING ones
		// included — are part of what goes down. Those attached to a declared
		// service are stopped/removed by the per-service loop below (they
		// match isService); the orphan branch at the end catches the
		// remainder (finished one-offs and model-absent services — see
		// isOrphaned). This is deliberately broader than `up
		// --remove-orphans`, which only cleans up FINISHED one-offs and never
		// kills a live `compose run` session.
		include = oneOffInclude
	}
	containers, err := s.getContainers(ctx, projectName, include, true)
	if err != nil {
		return err
	}

	project := options.Project
	if project == nil {
		project, err = s.getProjectWithResources(ctx, containers, projectName)
		if err != nil {
			return err
		}
	}

	// keep only the requested services that exist in the model
	var services []string
	for _, service := range options.Services {
		if _, err := project.GetService(service); err != nil {
			if options.Project != nil {
				// ran with an explicit compose.yaml file, so we should not ignore
				return err
			}
			// ran without an explicit compose.yaml file, so can't distinguish typo vs container already removed
			continue
		}
		services = append(services, service)
	}

	if len(options.Services) > 0 && len(services) == 0 {
		logrus.Infof("Any of the services %v not running in project %q", options.Services, projectName)
		return nil
	}

	options.Services = services

	if len(containers) > 0 {
		resourceToRemove = true
	}

	// shared across services — see restart.go's newOptionalLimiter comment
	// for why a per-service limiter alone isn't enough.
	limiter := newOptionalLimiter(s.maxConcurrency)

	err = InReverseDependencyOrder(ctx, project, func(c context.Context, service string) error {
		return s.downService(ctx, project, containers, options, service, limiter)
	}, WithRootNodesAndDown(options.Services))
	if err != nil {
		return err
	}

	orphans := containers.filter(isOrphaned(project))
	if options.RemoveOrphans && len(orphans) > 0 {
		err := s.removeContainers(ctx, orphans, nil, options.Timeout, false, limiter)
		if err != nil {
			return err
		}
	}

	if err := s.removePreStartHookContainers(ctx, projectName, options.Services); err != nil {
		return err
	}

	ops := s.ensureNetworksDown(ctx, project, limiter)
	ops = append(ops, s.ensureRelayLinkNetworksDown(ctx, project, limiter)...)

	if options.Images != "" {
		ops = append(ops, s.ensureImagesDown(ctx, project, options, limiter)...)
	}

	if options.Volumes {
		ops = append(ops, s.ensureVolumesDown(ctx, project, limiter)...)
	}

	if !resourceToRemove && len(ops) == 0 {
		logrus.Warnf("Warning: No resource found to remove for project %q.", projectName)
	}

	// ops dispatch itself is intentionally unbounded: each op already gates
	// its own engine call(s) on the shared limiter (network/volume ops
	// directly, image ops internally via their own forEachWithLimiter call),
	// so bounding this dispatch too on the same limiter would have an op
	// hold a slot for its own fan-out to acquire from -- deadlocking once
	// enough ops are in flight to exhaust it (see
	// TestDown_NetworkAndImageRemovalShareConcurrencyBudget).
	eg, ctx := errgroup.WithContext(ctx)
	for _, op := range ops {
		eg.Go(op)
	}
	return eg.Wait()
}

func (s *composeService) ensureVolumesDown(ctx context.Context, project *types.Project, limiter *semaphore.Weighted) []downOp {
	var ops []downOp
	for _, vol := range project.Volumes {
		if vol.External {
			continue
		}
		volumeName := vol.Name
		ops = append(ops, func() error {
			if err := acquireSlot(ctx, limiter); err != nil {
				return err
			}
			defer releaseSlot(limiter)
			return s.removeVolume(ctx, volumeName)
		})
	}

	return ops
}

func (s *composeService) ensureImagesDown(ctx context.Context, project *types.Project, options api.DownOptions, limiter *semaphore.Weighted) []downOp {
	pruneOpts := ImagePruneOptions{
		Mode:          ImagePruneMode(options.Images),
		RemoveOrphans: options.RemoveOrphans,
	}

	var ops []downOp
	if pruneOpts.Mode != ImagePruneNone {
		ops = append(ops, func() error {
			return s.removeTaggedImagesOp(ctx, project, pruneOpts, limiter)
		})

		// a dangling image from a service no longer in the project must be
		// spared unless RemoveOrphans is set, same as that service's tagged
		// image is (imageBelongsToKnownService is ImagesToPrune's own check).
		keep := func(img image.Summary) bool {
			return !imageBelongsToKnownService(project, options.RemoveOrphans, img)
		}
		projectName := project.Name
		ops = append(ops, func() error {
			return s.removeDanglingImagesOp(ctx, projectName, keep, limiter)
		})
	}
	return ops
}

// removeTaggedImagesOp computes the project's tagged images to prune and
// removes them, deferring the listing (which itself calls the daemon and
// can fail) to when the op actually runs, for the same reason
// removeDanglingImagesOp does: a listing failure here must not abort
// sibling down ops (network, volumes, dangling images), since — unlike
// this op — they've already been scheduled onto the same errgroup by the
// time `ensureImagesDown` used to fail synchronously.
//
// limiter is shared with the rest of down's ops (see down()'s comment) so
// this op's fan-out doesn't spend its own full maxConcurrency budget on top
// of removeDanglingImagesOp's, which runs concurrently with it.
func (s *composeService) removeTaggedImagesOp(ctx context.Context, project *types.Project, pruneOpts ImagePruneOptions, limiter *semaphore.Weighted) error {
	images, err := NewImagePruner(s.apiClient(), project, limiter).ImagesToPrune(ctx, pruneOpts)
	if err != nil {
		s.events.On(errorEvent("Tagged images", err.Error()))
		return err
	}

	var mu sync.Mutex
	var errs []error
	// forEachWithLimiter's own error handling isn't used here since a single
	// image failure must not cancel the shared errgroup ctx (see
	// TestRemoveTaggedImagesOp_ContinuesAfterOneImageFails) -- every failure
	// is collected instead, so fn itself always returns nil.
	_ = forEachWithLimiter(ctx, limiter, images, func(ctx context.Context, img string) error {
		if err := s.removeResource("Image "+img, func() error {
			_, err := s.apiClient().ImageRemove(ctx, img, client.ImageRemoveOptions{})
			return err
		}); err != nil {
			mu.Lock()
			errs = append(errs, err)
			mu.Unlock()
		}
		return nil
	})
	return errors.Join(errs...)
}

// removeDanglingImagesOp lists a project's dangling images and removes those
// not spared by keep, deferring both the listing and the removal to when the
// op actually runs so a failure here can't abort the rest of `down` (this op
// runs concurrently with the other resource-removal ops, same as any of
// them).
//
// It stays silent when there's nothing to remove, mirroring removeNetwork's
// silent skip. A listing failure surfaces under the "Dangling images" label
// as a plain error rather than the normal Removing/Removed progression,
// since at that point we don't know whether it would have been a no-op or
// a real removal.
//
// A removal failure keeps the "Removed" label only if at least one image
// actually got removed — with the error visible alongside it, not
// replacing it — otherwise it's reported as a plain error. removeImages
// also tolerates images that are already gone or still in use without that
// being an error, so a nil error here doesn't mean every image was actually
// removed either: stillInUse (a real, not-yet-achieved goal) is checked
// separately, the same distinction removeResource already makes per tagged
// image (an already-gone image simply isn't counted in either bucket).
func (s *composeService) removeDanglingImagesOp(ctx context.Context, projectName string, keep func(image.Summary) bool, limiter *semaphore.Weighted) error {
	eventID := "Dangling images"
	eligible, err := s.eligibleDanglingImages(ctx, projectName, keep)
	if err != nil {
		s.events.On(errorEvent(eventID, err.Error()))
		return err
	}
	if len(eligible) == 0 {
		return nil
	}

	s.events.On(removingEvent(eventID))
	removed, stillInUse, err := s.removeImages(ctx, eligible, limiter)
	var stillInUseNote string
	if len(stillInUse) > 0 {
		stillInUseNote = fmt.Sprintf("%d image(s) still in use", len(stillInUse))
	}
	switch {
	case err != nil:
		details := err.Error()
		if stillInUseNote != "" {
			details = fmt.Sprintf("%s; %s", details, stillInUseNote)
		}
		if len(removed) == 0 {
			s.events.On(errorEvent(eventID, details))
		} else {
			s.events.On(newEvent(eventID, api.Warning, "Removed", details))
		}
	case len(stillInUse) > 0 && len(removed) == 0:
		s.events.On(newEvent(eventID, api.Warning, "Resource is still in use", stillInUseNote))
	case len(stillInUse) > 0:
		s.events.On(newEvent(eventID, api.Warning, "Removed", stillInUseNote))
	case len(removed) == 0:
		// every eligible image was already gone by the time we got to it:
		// we already emitted "Removing", so this needs a terminal event
		// too, not silence — same wording removeResource uses for a
		// not-found tagged image.
		s.events.On(newEvent(eventID, api.Done, "Warning: No resource found to remove"))
	default:
		s.events.On(removedEvent(eventID))
	}
	return err
}

func (s *composeService) ensureNetworksDown(ctx context.Context, project *types.Project, limiter *semaphore.Weighted) []downOp {
	var ops []downOp
	for key, n := range project.Networks {
		if n.External {
			continue
		}
		// loop capture variable for op closure
		networkKey := key
		idOrName := n.Name
		ops = append(ops, func() error {
			if err := acquireSlot(ctx, limiter); err != nil {
				return err
			}
			defer releaseSlot(limiter)
			return s.removeNetwork(ctx, networkKey, project.Name, idOrName)
		})
	}
	return ops
}

func (s *composeService) removeNetwork(ctx context.Context, composeNetworkName string, projectName string, name string) error {
	res, err := s.apiClient().NetworkList(ctx, client.NetworkListOptions{
		Filters: projectFilter(projectName).Add("label", networkFilter(composeNetworkName)),
	})
	if err != nil {
		return fmt.Errorf("failed to list networks: %w", err)
	}
	networks := res.Items

	if len(networks) == 0 {
		return nil
	}

	eventName := "Network " + name
	s.events.On(removingEvent(eventName))

	var found int
	for _, net := range networks {
		if net.Name != name {
			continue
		}
		nwInspect, err := s.apiClient().NetworkInspect(ctx, net.ID, client.NetworkInspectOptions{})
		if errdefs.IsNotFound(err) {
			s.events.On(newEvent(eventName, api.Warning, "No resource found to remove"))
			return nil
		}
		if err != nil {
			return err
		}
		inspectedNetwork := nwInspect.Network
		if len(inspectedNetwork.Containers) > 0 {
			s.events.On(newEvent(eventName, api.Warning, "Resource is still in use"))
			found++
			continue
		}

		if _, err := s.apiClient().NetworkRemove(ctx, net.ID, client.NetworkRemoveOptions{}); err != nil {
			if errdefs.IsNotFound(err) {
				continue
			}
			s.events.On(errorEvent(eventName, err.Error()))
			return fmt.Errorf("failed to remove network %s: %w", name, err)
		}
		s.events.On(removedEvent(eventName))
		found++
	}

	if found == 0 {
		// in practice, it's extremely unlikely for this to ever occur, as it'd
		// mean the network was present when we queried at the start of this
		// method but was then deleted by something else in the interim
		s.events.On(newEvent(eventName, api.Warning, "No resource found to remove"))
		return nil
	}
	return nil
}

func (s *composeService) removeVolume(ctx context.Context, id string) error {
	resource := "Volume " + id

	_, err := s.apiClient().VolumeInspect(ctx, id, client.VolumeInspectOptions{})
	if errdefs.IsNotFound(err) {
		// Already gone
		return nil
	}

	return s.removeResource(resource, func() error {
		_, err := s.apiClient().VolumeRemove(ctx, id, client.VolumeRemoveOptions{
			Force: true,
		})
		return err
	})
}

// classifyRemovalError reports whether a resource-removal error is a benign
// "still in use" (Conflict) or "already gone" (NotFound) condition, as
// opposed to a genuine failure that must be surfaced. Shared by
// removeResource (single resource) and removeImages (a batch), so the two
// can't independently drift on what counts as tolerable.
func classifyRemovalError(err error) (stillInUse, alreadyGone bool) {
	return errdefs.IsConflict(err), errdefs.IsNotFound(err)
}

// removeResource emits a "Removing" progress event, calls op, then emits the appropriate
// completion event based on the error: nil→Removed, conflict→still-in-use warning, not-found→gone warning.
func (s *composeService) removeResource(eventID string, op func() error) error {
	s.events.On(newEvent(eventID, api.Working, "Removing"))
	err := op()
	if err == nil {
		s.events.On(newEvent(eventID, api.Done, "Removed"))
		return nil
	}
	stillInUse, alreadyGone := classifyRemovalError(err)
	if stillInUse {
		s.events.On(newEvent(eventID, api.Warning, "Resource is still in use"))
		return nil
	}
	if alreadyGone {
		s.events.On(newEvent(eventID, api.Done, "Warning: No resource found to remove"))
		return nil
	}
	return err
}

func (s *composeService) stopContainer(ctx context.Context, service *types.ServiceConfig, ctr containerType.Summary, timeout *time.Duration, listener api.ContainerEventListener) error {
	eventName := getContainerProgressName(ctr)
	s.events.On(newEvent(eventName, api.Working, api.StatusStopping))

	if service != nil && !isRelayContainer(ctr) {
		for _, hook := range service.PreStop {
			err := s.runHook(ctx, ctr, *service, hook, listener)
			if err != nil {
				// Ignore errors indicating that some containers were already stopped or removed.
				if errdefs.IsNotFound(err) || errdefs.IsConflict(err) {
					return nil
				}
				return err
			}
		}
	}

	_, err := s.apiClient().ContainerStop(ctx, ctr.ID, client.ContainerStopOptions{
		Timeout: utils.DurationSecondToInt(timeout),
	})
	if err != nil {
		s.events.On(errorEvent(eventName, "Error while Stopping"))
		return err
	}
	s.events.On(newEvent(eventName, api.Done, api.StatusStopped))
	return nil
}

func (s *composeService) stopContainers(
	ctx context.Context,
	serv *types.ServiceConfig,
	containers []containerType.Summary,
	timeout *time.Duration,
	listener api.ContainerEventListener,
	limiter *semaphore.Weighted,
) error {
	return forEachWithLimiter(ctx, limiter, containers, func(ctx context.Context, ctr containerType.Summary) error {
		return s.stopContainer(ctx, serv, ctr, timeout, listener)
	})
}

func (s *composeService) removeContainers(
	ctx context.Context,
	containers []containerType.Summary,
	service *types.ServiceConfig,
	timeout *time.Duration,
	volumes bool,
	limiter *semaphore.Weighted,
) error {
	return forEachWithLimiter(ctx, limiter, containers, func(ctx context.Context, ctr containerType.Summary) error {
		return s.stopAndRemoveContainer(ctx, ctr, service, timeout, volumes)
	})
}

func (s *composeService) stopAndRemoveContainer(ctx context.Context, ctr containerType.Summary, service *types.ServiceConfig, timeout *time.Duration, volumes bool) error {
	eventName := getContainerProgressName(ctr)
	err := s.stopContainer(ctx, service, ctr, timeout, nil)
	if errdefs.IsNotFound(err) {
		s.events.On(removedEvent(eventName))
		return nil
	}
	if err != nil {
		return err
	}
	s.events.On(removingEvent(eventName))
	_, err = s.apiClient().ContainerRemove(ctx, ctr.ID, client.ContainerRemoveOptions{
		Force:         true,
		RemoveVolumes: volumes,
	})
	if err != nil && !errdefs.IsNotFound(err) && !errdefs.IsConflict(err) {
		s.events.On(errorEvent(eventName, "Error while Removing"))
		return err
	}
	s.events.On(removedEvent(eventName))
	return nil
}

// downService removes one service's containers. A provider service may still
// own project containers — the relay deployed when it published endpoints —
// and the plugin only removes the provider's own resource, so the containers
// go first, mirroring up, which provisions the resource before the relay.
func (s *composeService) downService(ctx context.Context, project *types.Project, containers Containers, options api.DownOptions, service string, limiter *semaphore.Weighted) error {
	serv := project.Services[service]
	serviceContainers := containers.filter(isService(service))
	if err := s.removeContainers(ctx, serviceContainers, &serv, options.Timeout, options.Volumes, limiter); err != nil {
		return err
	}
	if serv.Provider != nil {
		return s.runPlugin(ctx, project, serv, "down")
	}
	return nil
}

func (s *composeService) getProjectWithResources(ctx context.Context, containers Containers, projectName string) (*types.Project, error) {
	containers = containers.filter(isNotOneOff)
	p, err := s.projectFromName(containers, projectName)
	if err != nil && !api.IsNotFoundError(err) {
		return nil, err
	}
	project, err := p.WithServicesTransform(func(name string, service types.ServiceConfig) (types.ServiceConfig, error) {
		for k := range service.DependsOn {
			if dependency, ok := service.DependsOn[k]; ok {
				dependency.Required = false
				service.DependsOn[k] = dependency
			}
		}
		return service, nil
	})
	if err != nil {
		return nil, err
	}

	volumes, err := s.actualVolumes(ctx, projectName)
	if err != nil {
		return nil, err
	}
	project.Volumes = volumes

	networks, err := s.actualNetworks(ctx, projectName)
	if err != nil {
		return nil, err
	}
	project.Networks = networks

	return project, nil
}

// removePreStartHookContainers force-removes any pre_start hook containers that
// were retained after a failed hook run. These containers are created without a
// ConfigHashLabel, so getContainers and the normal teardown path never see them;
// without this step they would survive compose down. When services is non-empty
// the cleanup is scoped to those services; otherwise the whole project is swept.
// Individual removal failures are logged at warn level and do not abort teardown.
func (s *composeService) removePreStartHookContainers(ctx context.Context, projectName string, services []string) error {
	var filters []client.Filters
	if len(services) == 0 {
		f := projectFilter(projectName)
		f.Add("label", hookFilter(preStartHookType))
		filters = []client.Filters{f}
	} else {
		for _, service := range services {
			f := projectFilter(projectName)
			f.Add("label", serviceFilter(service))
			f.Add("label", hookFilter(preStartHookType))
			filters = append(filters, f)
		}
	}
	for _, f := range filters {
		res, err := s.apiClient().ContainerList(ctx, client.ContainerListOptions{
			All:     true,
			Filters: f,
		})
		if err != nil {
			return err
		}
		for _, ctr := range res.Items {
			if _, removeErr := s.apiClient().ContainerRemove(ctx, ctr.ID, client.ContainerRemoveOptions{
				Force:         true,
				RemoveVolumes: true,
			}); removeErr != nil {
				logrus.Warnf("failed to remove retained pre_start hook container %s: %v", ctr.ID, removeErr)
			}
		}
	}
	return nil
}
