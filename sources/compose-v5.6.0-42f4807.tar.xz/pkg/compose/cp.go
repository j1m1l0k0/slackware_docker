/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package compose

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/docker/cli/cli/command"
	"github.com/moby/go-archive"
	"github.com/moby/moby/api/types/container"
	"github.com/moby/moby/client"

	"github.com/docker/compose/v5/pkg/api"
)

type copyDirection int

const (
	fromService copyDirection = 1 << iota
	toService
	acrossServices = fromService | toService
)

func (s *composeService) Copy(ctx context.Context, projectName string, options api.CopyOptions) error {
	return Run(ctx, func(ctx context.Context) error {
		return s.copy(ctx, projectName, options)
	}, "copy", s.events)
}

func (s *composeService) copy(ctx context.Context, projectName string, options api.CopyOptions) error {
	projectName = strings.ToLower(projectName)
	srcService, srcPath := splitCpArg(options.Source)
	destService, dstPath := splitCpArg(options.Destination)

	var direction copyDirection
	var serviceName string
	var copyFunc func(ctx context.Context, containerID string, srcPath string, dstPath string, options api.CopyOptions) error
	if srcService != "" {
		direction |= fromService
		serviceName = srcService
		copyFunc = s.copyFromContainer
	}
	if destService != "" {
		direction |= toService
		serviceName = destService
		copyFunc = s.copyToContainer
	}
	if direction == acrossServices {
		return errors.New("copying between services is not supported")
	}

	if direction == 0 {
		return errors.New("unknown copy direction")
	}

	containers, err := s.listContainersTargetedForCopy(ctx, projectName, options, direction, serviceName)
	if err != nil {
		return err
	}

	return forEachContainerConcurrent(ctx, s.maxConcurrency, containers, func(ctx context.Context, ctr container.Summary) error {
		name := getCanonicalContainerName(ctr)
		var msg string
		if direction == fromService {
			msg = fmt.Sprintf("%s:%s to %s", name, srcPath, dstPath)
		} else {
			msg = fmt.Sprintf("%s to %s:%s", srcPath, name, dstPath)
		}
		s.events.On(api.Resource{
			ID:      name,
			Text:    api.StatusCopying,
			Details: msg,
			Status:  api.Working,
		})
		if err := copyFunc(ctx, ctr.ID, srcPath, dstPath, options); err != nil {
			return err
		}
		s.events.On(api.Resource{
			ID:      name,
			Text:    api.StatusCopied,
			Details: msg,
			Status:  api.Done,
		})
		return nil
	})
}

func (s *composeService) listContainersTargetedForCopy(ctx context.Context, projectName string, options api.CopyOptions, direction copyDirection, serviceName string) (Containers, error) {
	var containers Containers
	var err error
	switch {
	case options.Index > 0:
		ctr, err := s.getSpecifiedContainer(ctx, projectName, oneOffExclude, true, serviceName, options.Index)
		if err != nil {
			return nil, err
		}
		if err := checkRelayTarget(ctr, serviceName, "cp"); err != nil {
			return nil, err
		}
		return append(containers, ctr), nil
	default:
		withOneOff := oneOffExclude
		if options.All {
			withOneOff = oneOffInclude
		}
		containers, err = s.getContainers(ctx, projectName, withOneOff, true, serviceName)
		if err != nil {
			return nil, err
		}
		for _, ctr := range containers {
			if err := checkRelayTarget(ctr, serviceName, "cp"); err != nil {
				return nil, err
			}
		}

		if len(containers) < 1 {
			return nil, fmt.Errorf("no container found for service %q", serviceName)
		}
		if direction == fromService {
			return containers[:1], err
		}
		return containers, err
	}
}

func (s *composeService) copyToContainer(ctx context.Context, containerID string, srcPath string, dstPath string, options api.CopyOptions) error {
	var err error
	if srcPath != "-" {
		// Get an absolute source path.
		srcPath, err = resolveLocalPath(srcPath)
		if err != nil {
			return err
		}
	}

	// Prepare destination copy info by stat-ing the container path.
	dstInfo := archive.CopyInfo{Path: dstPath}
	var dstStat container.PathStat
	res, err := s.apiClient().ContainerStatPath(ctx, containerID, client.ContainerStatPathOptions{
		Path: dstPath,
	})
	if err == nil {
		dstStat = res.Stat
	}

	// If the destination is a symbolic link, we should evaluate it.
	if err == nil && dstStat.Mode&os.ModeSymlink != 0 {
		linkTarget := dstStat.LinkTarget
		if !isAbs(linkTarget) {
			// Join with the parent directory.
			dstParent, _ := archive.SplitPathDirEntry(dstPath)
			linkTarget = filepath.Join(dstParent, linkTarget)
		}

		dstInfo.Path = linkTarget
		res, err = s.apiClient().ContainerStatPath(ctx, containerID, client.ContainerStatPathOptions{
			Path: linkTarget,
		})
		if err == nil {
			dstStat = res.Stat
		}
	}

	// Validate the destination path
	if err := command.ValidateOutputPathFileMode(dstStat.Mode); err != nil {
		return fmt.Errorf(`destination "%s:%s" must be a directory or a regular file: %w`, containerID, dstPath, err)
	}

	// Ignore any error and assume that the parent directory of the destination
	// path exists, in which case the copy may still succeed. If there is any
	// type of conflict (e.g., non-directory overwriting an existing directory
	// or vice versa) the extraction will fail. If the destination simply did
	// not exist, but the parent directory does, the extraction will still
	// succeed.
	if err == nil {
		dstInfo.Exists, dstInfo.IsDir = true, dstStat.Mode.IsDir()
	}

	var (
		content         io.Reader
		resolvedDstPath string
	)

	if srcPath == "-" {
		content = s.stdin()
		resolvedDstPath = dstInfo.Path
		if !dstInfo.IsDir {
			return fmt.Errorf("destination \"%s:%s\" must be a directory", containerID, dstPath)
		}
	} else {
		// Prepare source copy info.
		srcInfo, err := archive.CopyInfoSourcePath(srcPath, options.FollowLink)
		if err != nil {
			return err
		}

		srcArchive, err := archive.TarResource(srcInfo)
		if err != nil {
			return err
		}
		defer srcArchive.Close() //nolint:errcheck

		// With the stat info about the local source as well as the
		// destination, we have enough information to know whether we need to
		// alter the archive that we upload so that when the server extracts
		// it to the specified directory in the container we get the desired
		// copy behavior.

		// See comments in the implementation of `archive.PrepareArchiveCopy`
		// for exactly what goes into deciding how and whether the source
		// archive needs to be altered for the correct copy behavior when it is
		// extracted. This function also infers from the source and destination
		// info which directory to extract to, which may be the parent of the
		// destination that the user specified.
		// Don't create the archive if running in Dry Run mode
		if !s.dryRun {
			dstDir, preparedArchive, err := archive.PrepareArchiveCopy(srcArchive, srcInfo, dstInfo)
			if err != nil {
				return err
			}
			defer preparedArchive.Close() //nolint:errcheck

			resolvedDstPath = dstDir
			content = preparedArchive
		}
	}

	_, err = s.apiClient().CopyToContainer(ctx, containerID, client.CopyToContainerOptions{
		DestinationPath:           resolvedDstPath,
		Content:                   content,
		AllowOverwriteDirWithFile: false,
		CopyUIDGID:                options.CopyUIDGID,
	})
	return err
}

func (s *composeService) copyFromContainer(ctx context.Context, containerID, srcPath, dstPath string, options api.CopyOptions) error {
	var err error
	if dstPath != "-" {
		// Get an absolute destination path.
		dstPath, err = resolveLocalPath(dstPath)
		if err != nil {
			return err
		}
	}

	if err := command.ValidateOutputPath(dstPath); err != nil {
		return err
	}

	// if client requests to follow symbol link, then must decide target file to be copied
	var rebaseName string
	if options.FollowLink {
		var srcStat container.PathStat
		res, err := s.apiClient().ContainerStatPath(ctx, containerID, client.ContainerStatPathOptions{
			Path: srcPath,
		})
		if err == nil {
			srcStat = res.Stat
		}

		// If the destination is a symbolic link, we should follow it.
		if err == nil && srcStat.Mode&os.ModeSymlink != 0 {
			linkTarget := srcStat.LinkTarget
			if !isAbs(linkTarget) {
				// Join with the parent directory.
				srcParent, _ := archive.SplitPathDirEntry(srcPath)
				linkTarget = filepath.Join(srcParent, linkTarget)
			}

			linkTarget, rebaseName = archive.GetRebaseName(srcPath, linkTarget)
			srcPath = linkTarget
		}
	}

	res, err := s.apiClient().CopyFromContainer(ctx, containerID, client.CopyFromContainerOptions{
		SourcePath: srcPath,
	})
	if err != nil {
		return err
	}
	defer res.Content.Close() //nolint:errcheck

	if dstPath == "-" {
		_, err = io.Copy(s.stdout(), res.Content)
		return err
	}

	srcInfo := archive.CopyInfo{
		Path:       srcPath,
		Exists:     true,
		IsDir:      res.Stat.Mode.IsDir(),
		RebaseName: rebaseName,
	}

	preArchive := res.Content
	if srcInfo.RebaseName != "" {
		_, srcBase := archive.SplitPathDirEntry(srcInfo.Path)
		preArchive = archive.RebaseArchiveEntries(res.Content, srcBase, srcInfo.RebaseName)
	}

	return archive.CopyTo(preArchive, srcInfo, dstPath)
}

// IsAbs is a platform-agnostic wrapper for filepath.IsAbs.
//
// On Windows, golang filepath.IsAbs does not consider a path \windows\system32
// as absolute as it doesn't start with a drive-letter/colon combination. However,
// in docker we need to verify things such as WORKDIR /windows/system32 in
// a Dockerfile (which gets translated to \windows\system32 when being processed
// by the daemon). This SHOULD be treated as absolute from a docker processing
// perspective.
func isAbs(path string) bool {
	return filepath.IsAbs(path) || strings.HasPrefix(path, string(os.PathSeparator))
}

func splitCpArg(arg string) (ctr, path string) {
	if isAbs(arg) {
		// Explicit local absolute path, e.g., `C:\foo` or `/foo`.
		return "", arg
	}

	ctr, path, ok := strings.Cut(arg, ":")

	if !ok || strings.HasPrefix(ctr, ".") {
		// Either there's no `:` in the arg
		// OR it's an explicit local relative path like `./file:name.txt`.
		return "", arg
	}

	return ctr, path
}

func resolveLocalPath(localPath string) (absPath string, err error) {
	if absPath, err = filepath.Abs(localPath); err != nil {
		return absPath, err
	}
	return archive.PreserveTrailingDotOrSeparator(absPath, localPath), nil
}
