/*
   Copyright 2024 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package display

// Mode is the effective progress rendering mode for the current command.
//
// It starts as ModeAuto and is resolved during command setup by
// selectEventProcessor (cmd/compose), which assigns the mode matching the
// renderer it returns — so code running after setup never observes ModeAuto.
// The only other writers are the `--quiet` flags of `run` and `build`, which
// force ModeQuiet from their PreRun hooks.
var Mode = ModeAuto

const (
	// ModeAuto detect console capabilities
	ModeAuto = "auto"
	// ModeTTY use terminal capability for advanced rendering
	ModeTTY = "tty"
	// ModePlain dump raw events to output
	ModePlain = "plain"
	// ModeQuiet don't display events
	ModeQuiet = "quiet"
	// ModeJSON outputs a machine-readable JSON stream
	ModeJSON = "json"
)
