/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package display

import (
	"context"

	"github.com/docker/compose/v5/pkg/api"
)

func Quiet() api.EventProcessor {
	return &quiet{}
}

type quiet struct{}

func (q *quiet) Start(_ context.Context, _ string) {
}

func (q *quiet) Done(_ string, _ bool) {
}

func (q *quiet) On(_ ...api.Resource) {
}
