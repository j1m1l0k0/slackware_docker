/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package compose

import (
	"strings"
	"testing"

	"github.com/compose-spec/compose-go/v2/types"
	"github.com/docker/cli/cli/config/configfile"
	"github.com/moby/moby/api/types/registry"
	"github.com/moby/moby/client"
	ocispec "github.com/opencontainers/image-spec/specs-go/v1"
	"go.uber.org/mock/gomock"
	"gotest.tools/v3/assert"

	"github.com/docker/compose/v5/pkg/mocks"
)

const testDigest = "sha256:1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"

func TestResolveImageDigests(t *testing.T) {
	// distinct digests per resolved reference, so attaching a digest to the wrong image would fail
	const (
		serviceDigest = "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
		hookDigest    = "sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"
		volumeDigest  = "sha256:cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"
		builderDigest = "sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"
	)
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	apiClient := mocks.NewMockAPIClient(mockCtrl)
	cli := mocks.NewMockCli(mockCtrl)
	cli.EXPECT().Client().Return(apiClient).AnyTimes()
	cli.EXPECT().ConfigFile().Return(configfile.New("")).AnyTimes()

	model := map[string]any{
		"services": map[string]any{
			"test": map[string]any{
				"image": "nginx:latest",
				"pre_start": []any{
					map[string]any{"command": "echo hello", "image": "hookimage:latest"},
					// hook running in the service container: no image to resolve
					map[string]any{"command": "echo hello"},
				},
				"volumes": []any{
					map[string]any{"type": "image", "source": "someimage:latest", "target": "/data"},
					// already digested: must NOT trigger any registry call and must be kept as-is
					map[string]any{"type": "image", "source": "docker.io/library/pinned@" + testDigest, "target": "/pinned"},
					// happens to share its name with the "builder" service below: a type=image
					// volume source is always a plain docker image reference (compose-go#929),
					// never an implicit reference to another service, so it still gets resolved
					map[string]any{"type": "image", "source": "builder", "target": "/built"},
					map[string]any{"type": "bind", "source": "/host", "target": "/bind"},
					"./data:/short",
				},
			},
			"builder": map[string]any{
				"image": "docker.io/library/pinned@" + testDigest,
			},
			// service without image: its image volumes must still be pinned, and
			// "someimage:latest" being also used by "test" must be resolved only once
			"data": map[string]any{
				"volumes": []any{
					map[string]any{"type": "image", "source": "someimage:latest", "target": "/data"},
				},
			},
		},
	}

	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/nginx:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: serviceDigest}},
		}, nil)
	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/someimage:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: volumeDigest}},
		}, nil)
	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/hookimage:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: hookDigest}},
		}, nil)
	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/builder:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: builderDigest}},
		}, nil)

	err := resolveImageDigests(t.Context(), cli, model)
	assert.NilError(t, err)

	services := model["services"].(map[string]any)
	service := services["test"].(map[string]any)
	assert.Equal(t, service["image"], "docker.io/library/nginx:latest@"+serviceDigest)
	hooks := service["pre_start"].([]any)
	assert.Equal(t, hooks[0].(map[string]any)["image"], "docker.io/library/hookimage:latest@"+hookDigest)
	_, hasImage := hooks[1].(map[string]any)["image"]
	assert.Assert(t, !hasImage)
	volumes := service["volumes"].([]any)
	assert.Equal(t, volumes[0].(map[string]any)["source"], "docker.io/library/someimage:latest@"+volumeDigest)
	assert.Equal(t, volumes[1].(map[string]any)["source"], "docker.io/library/pinned@"+testDigest)
	assert.Equal(t, volumes[2].(map[string]any)["source"], "docker.io/library/builder:latest@"+builderDigest)
	assert.Equal(t, volumes[3].(map[string]any)["source"], "/host")
	assert.Equal(t, volumes[4], "./data:/short")
	assert.Equal(t, services["builder"].(map[string]any)["image"], "docker.io/library/pinned@"+testDigest)
	dataVolumes := services["data"].(map[string]any)["volumes"].([]any)
	assert.Equal(t, dataVolumes[0].(map[string]any)["source"], "docker.io/library/someimage:latest@"+volumeDigest)
}

func TestResolveImageDigestsWithoutServices(t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	cli := mocks.NewMockCli(mockCtrl)
	cli.EXPECT().Client().Return(mocks.NewMockAPIClient(mockCtrl)).AnyTimes()
	cli.EXPECT().ConfigFile().Return(configfile.New("")).AnyTimes()

	// top-level services is optional in the compose spec, and unlike the typed
	// project the raw model gets no empty services map from normalization
	model := map[string]any{
		"networks": map[string]any{"foo": nil},
	}

	err := resolveImageDigests(t.Context(), cli, model)
	assert.NilError(t, err)
}

// A job's image and `type: image` volume sources must resolve the same way a
// service's do -- jobs share the same build-and-publish surface, and
// resolveImageDigests originally only walked model["services"].
func TestResolveImageDigestsWithJobs(t *testing.T) {
	const (
		serviceDigest = "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
		jobDigest     = "sha256:dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd"
		jobVolDigest  = "sha256:eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
	)
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()
	apiClient := mocks.NewMockAPIClient(mockCtrl)
	cli := mocks.NewMockCli(mockCtrl)
	cli.EXPECT().Client().Return(apiClient).AnyTimes()
	cli.EXPECT().ConfigFile().Return(configfile.New("")).AnyTimes()

	model := map[string]any{
		"services": map[string]any{
			"web": map[string]any{"image": "nginx:latest"},
		},
		"jobs": map[string]any{
			"migrate": map[string]any{
				"image": "migrate:latest",
				"volumes": []any{
					map[string]any{"type": "image", "source": "migrate-data:latest", "target": "/data"},
				},
			},
		},
	}

	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/nginx:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: serviceDigest}},
		}, nil)
	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/migrate:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: jobDigest}},
		}, nil)
	apiClient.EXPECT().DistributionInspect(gomock.Any(), "docker.io/library/migrate-data:latest", gomock.Any()).
		Return(client.DistributionInspectResult{
			DistributionInspect: registry.DistributionInspect{Descriptor: ocispec.Descriptor{Digest: jobVolDigest}},
		}, nil)

	err := resolveImageDigests(t.Context(), cli, model)
	assert.NilError(t, err)

	service := model["services"].(map[string]any)["web"].(map[string]any)
	assert.Equal(t, service["image"], "docker.io/library/nginx:latest@"+serviceDigest)

	job := model["jobs"].(map[string]any)["migrate"].(map[string]any)
	assert.Equal(t, job["image"], "docker.io/library/migrate:latest@"+jobDigest)
	volumes := job["volumes"].([]any)
	assert.Equal(t, volumes[0].(map[string]any)["source"], "docker.io/library/migrate-data:latest@"+jobVolDigest)
}

func TestImagesOnly(t *testing.T) {
	project := &types.Project{
		Name: "test",
		Services: types.Services{
			"test": types.ServiceConfig{
				Name: "test",

				// hooks can't be overridden element-wise on merge, so the lock must not carry them
				PreStart: []types.PreStartHook{{ContainerSpec: types.ContainerSpec{Image: "docker.io/library/hookimage@" + testDigest}}}, ContainerSpec: types.ContainerSpec{
					Image:   "docker.io/library/nginx@" + testDigest,
					Command: types.ShellCommand{"echo", "hello"},

					Volumes: []types.ServiceVolumeConfig{
						{Type: types.VolumeTypeImage, Source: "docker.io/library/someimage@" + testDigest, Target: "/data"},
						{Type: types.VolumeTypeBind, Source: "/host", Target: "/bind"},
					},
				},
			},
		},
		Networks: types.Networks{"default": types.NetworkConfig{}},
	}

	locked := imagesOnly(project)

	assert.DeepEqual(t, locked, &types.Project{
		Services: types.Services{
			"test": types.ServiceConfig{
				ContainerSpec: types.ContainerSpec{
					Image: "docker.io/library/nginx@" + testDigest,
					Volumes: []types.ServiceVolumeConfig{
						{Type: types.VolumeTypeImage, Source: "docker.io/library/someimage@" + testDigest, Target: "/data"},
					},
				},
			},
		},
	})
}

func TestWarnHooksNotLockable(t *testing.T) {
	messages := captureWarnings(t, func() {
		warnHooksNotLockable(&types.Project{
			Services: types.Services{
				"with-hook-image": types.ServiceConfig{PreStart: []types.PreStartHook{{ContainerSpec: types.ContainerSpec{Image: "alpine:latest"}}}},
				"inline-hook":     types.ServiceConfig{PreStart: []types.PreStartHook{{ContainerSpec: types.ContainerSpec{Command: types.ShellCommand{"echo"}}}}},
				"without-hook":    types.ServiceConfig{},
			},
		})
	})

	assert.Equal(t, len(messages), 1)
	assert.Assert(t, strings.Contains(messages[0], `service "with-hook-image"`))
}

func TestWarnModelHooksNotLockable(t *testing.T) {
	messages := captureWarnings(t, func() {
		warnModelHooksNotLockable(map[string]any{
			"services": map[string]any{
				"with-hook-image": map[string]any{
					"pre_start": []any{map[string]any{"image": "alpine:latest"}},
				},
				"inline-hook": map[string]any{
					"pre_start": []any{map[string]any{"command": "echo"}},
				},
				"without-hook": map[string]any{"image": "nginx"},
			},
		})
	})

	assert.Equal(t, len(messages), 1)
	assert.Assert(t, strings.Contains(messages[0], `service "with-hook-image"`))
}

func TestLockModel(t *testing.T) {
	model := map[string]any{
		"name": "test",
		"services": map[string]any{
			"a": map[string]any{
				"image":   "docker.io/library/nginx@" + testDigest,
				"command": "echo hello",
				// hooks can't be overridden element-wise on merge, so the lock must not carry them
				"pre_start": []any{
					map[string]any{"image": "docker.io/library/hookimage@" + testDigest},
				},
				"volumes": []any{
					map[string]any{"type": "image", "source": "docker.io/library/someimage@" + testDigest, "target": "/data"},
					map[string]any{"type": "bind", "source": "/host", "target": "/bind"},
				},
			},
			"b": map[string]any{
				"image": "docker.io/library/alpine@" + testDigest,
				"volumes": []any{
					map[string]any{"type": "bind", "source": "/host", "target": "/bind"},
				},
			},
		},
		"networks": map[string]any{"default": nil},
	}

	lockModel(model)

	assert.DeepEqual(t, model, map[string]any{
		"services": map[string]any{
			"a": map[string]any{
				"image": "docker.io/library/nginx@" + testDigest,
				// volumes keeps its []any raw-model type after filtering
				"volumes": []any{
					map[string]any{"type": "image", "source": "docker.io/library/someimage@" + testDigest, "target": "/data"},
				},
			},
			"b": map[string]any{
				"image": "docker.io/library/alpine@" + testDigest,
			},
		},
	})
}
