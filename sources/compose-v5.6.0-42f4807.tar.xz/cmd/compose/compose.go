/*
   Copyright 2020 Docker Compose CLI authors

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package compose

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"

	"github.com/compose-spec/compose-go/v2/cli"
	"github.com/compose-spec/compose-go/v2/dotenv"
	"github.com/compose-spec/compose-go/v2/loader"
	composepaths "github.com/compose-spec/compose-go/v2/paths"
	"github.com/compose-spec/compose-go/v2/types"
	composegoutils "github.com/compose-spec/compose-go/v2/utils"
	dockercli "github.com/docker/cli/cli"
	"github.com/docker/cli/cli-plugins/metadata"
	"github.com/docker/cli/cli/command"
	"github.com/docker/cli/pkg/kvfile"
	"github.com/morikuni/aec"
	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"

	"github.com/docker/compose/v5/cmd/display"
	"github.com/docker/compose/v5/cmd/formatter"
	"github.com/docker/compose/v5/internal/tracing"
	"github.com/docker/compose/v5/pkg/api"
	"github.com/docker/compose/v5/pkg/compose"
	"github.com/docker/compose/v5/pkg/remote"
	"github.com/docker/compose/v5/pkg/utils"
)

const (
	// ComposeParallelLimit set the limit running concurrent operation on docker engine
	ComposeParallelLimit = "COMPOSE_PARALLEL_LIMIT"
	// ComposeProjectName define the project name to be used, instead of guessing from parent directory
	ComposeProjectName = "COMPOSE_PROJECT_NAME"
	// ComposeCompatibility try to mimic compose v1 as much as possible
	ComposeCompatibility = api.ComposeCompatibility
	// ComposeRemoveOrphans remove "orphaned" containers, i.e. containers tagged for current project but not declared as service
	ComposeRemoveOrphans = "COMPOSE_REMOVE_ORPHANS"
	// ComposeIgnoreOrphans ignore "orphaned" containers
	ComposeIgnoreOrphans = "COMPOSE_IGNORE_ORPHANS"
	// ComposeEnvFiles defines the env files to use if --env-file isn't used
	ComposeEnvFiles = "COMPOSE_ENV_FILES"
	// ComposeMenu defines if the navigation menu should be rendered. Can be also set via --menu
	ComposeMenu = "COMPOSE_MENU"
	// ComposeProgress defines type of progress output, if --progress isn't used
	ComposeProgress = "COMPOSE_PROGRESS"
)

// rawEnv load a dot env file using docker/cli key=value parser, without attempt to interpolate or evaluate values
func rawEnv(r io.Reader, filename string, vars map[string]string, lookup func(key string) (string, bool)) error {
	lines, err := kvfile.ParseFromReader(r, lookup)
	if err != nil {
		return fmt.Errorf("failed to parse env_file %s: %w", filename, err)
	}
	for _, line := range lines {
		key, value, _ := strings.Cut(line, "=")
		vars[key] = value
	}
	return nil
}

var stdioToStdout bool

func init() {
	// compose evaluates env file values for interpolation
	// `raw` format allows to load env_file with the same parser used by docker run --env-file
	dotenv.RegisterFormat("raw", rawEnv)

	if v, ok := os.LookupEnv("COMPOSE_STATUS_STDOUT"); ok {
		stdioToStdout, _ = strconv.ParseBool(v)
	}
}

// Command defines a compose CLI command as a func with args
type Command func(context.Context, []string) error

// CobraCommand defines a cobra command function
type CobraCommand func(context.Context, *cobra.Command, []string) error

// AdaptCmd adapt a CobraCommand func to cobra library
func AdaptCmd(fn CobraCommand) func(cmd *cobra.Command, args []string) error {
	return func(cmd *cobra.Command, args []string) error {
		ctx, cancel := context.WithCancel(cmd.Context())

		s := make(chan os.Signal, 1)
		signal.Notify(s, syscall.SIGTERM, syscall.SIGINT)
		go func() {
			<-s
			cancel()
			signal.Stop(s)
			close(s)
		}()

		err := fn(ctx, cmd, args)
		if api.IsErrCanceled(err) || errors.Is(ctx.Err(), context.Canceled) {
			err = dockercli.StatusError{
				StatusCode: 130,
			}
		}
		if display.Mode == display.ModeJSON {
			err = makeJSONError(err)
		}
		return err
	}
}

// Adapt a Command func to cobra library
func Adapt(fn Command) func(cmd *cobra.Command, args []string) error {
	return AdaptCmd(func(ctx context.Context, cmd *cobra.Command, args []string) error {
		return fn(ctx, args)
	})
}

type ProjectOptions struct {
	ProjectName           string
	Profiles              []string
	ConfigPaths           []string
	WorkDir               string
	ProjectDir            string
	EnvFiles              []string
	Compatibility         bool
	Progress              string
	Offline               bool
	All                   bool
	insecureRegistries    []string
	remoteLoadersOverride []loader.ResourceLoader
}

// ProjectFunc does stuff within a types.Project
type ProjectFunc func(ctx context.Context, project *types.Project) error

// ProjectServicesFunc does stuff within a types.Project and a selection of services
type ProjectServicesFunc func(ctx context.Context, project *types.Project, services []string) error

// WithProject creates a cobra run command from a ProjectFunc based on configured project options and selected services
func (o *ProjectOptions) WithProject(fn ProjectFunc, dockerCli command.Cli) func(cmd *cobra.Command, args []string) error {
	return o.WithServices(dockerCli, func(ctx context.Context, project *types.Project, services []string) error {
		return fn(ctx, project)
	})
}

// WithServices creates a cobra run command from a ProjectFunc based on configured project options and selected services
func (o *ProjectOptions) WithServices(dockerCli command.Cli, fn ProjectServicesFunc) func(cmd *cobra.Command, args []string) error {
	return Adapt(func(ctx context.Context, services []string) error {
		backend, err := compose.NewComposeService(dockerCli)
		if err != nil {
			return err
		}

		project, metrics, err := o.ToProject(ctx, dockerCli, backend, services, warnUnsupportedAttributes, cli.WithoutEnvironmentResolution)
		if err != nil {
			return err
		}

		ctx = context.WithValue(ctx, tracing.MetricsKey{}, metrics)

		project, err = project.WithServicesEnvironmentResolved(true)
		if err != nil {
			return err
		}

		return fn(ctx, project, services)
	})
}

type jsonErrorData struct {
	Error   bool   `json:"error,omitempty"`
	Message string `json:"message,omitempty"`
}

func errorAsJSON(message string) string {
	errorMessage := &jsonErrorData{
		Error:   true,
		Message: message,
	}
	marshal, err := json.Marshal(errorMessage)
	if err == nil {
		return string(marshal)
	} else {
		return message
	}
}

func makeJSONError(err error) error {
	if err == nil {
		return nil
	}
	var statusErr dockercli.StatusError
	if errors.As(err, &statusErr) {
		return dockercli.StatusError{
			StatusCode: statusErr.StatusCode,
			Status:     errorAsJSON(statusErr.Status),
		}
	}
	return fmt.Errorf("%s", errorAsJSON(err.Error()))
}

func (o *ProjectOptions) addProjectFlags(f *pflag.FlagSet) {
	f.StringArrayVar(&o.Profiles, "profile", []string{}, "Specify a profile to enable")
	f.StringVarP(&o.ProjectName, "project-name", "p", "", "Project name")
	f.StringArrayVarP(&o.ConfigPaths, "file", "f", []string{}, "Compose configuration files")
	f.StringArrayVar(&o.insecureRegistries, "insecure-registry", []string{}, "Use insecure registry to pull Compose OCI artifacts. Doesn't apply to images")
	_ = f.MarkHidden("insecure-registry")
	f.StringArrayVar(&o.EnvFiles, "env-file", defaultStringArrayVar(ComposeEnvFiles), "Specify an alternate environment file")
	f.StringVar(&o.ProjectDir, "project-directory", "", "Specify an alternate working directory\n(default: the path of the, first specified, Compose file)")
	f.StringVar(&o.WorkDir, "workdir", "", "DEPRECATED! USE --project-directory INSTEAD.\nSpecify an alternate working directory\n(default: the path of the, first specified, Compose file)")
	f.BoolVar(&o.Compatibility, "compatibility", false, "Run compose in backward compatibility mode")
	f.StringVar(&o.Progress, "progress", os.Getenv(ComposeProgress), fmt.Sprintf(`Set type of progress output (%s)`, strings.Join(printerModes, ", ")))
	f.BoolVar(&o.All, "all-resources", false, "Include all resources, even those not used by services")
	_ = f.MarkHidden("workdir")
}

// get default value for a command line flag that is set by a coma-separated value in environment variable
func defaultStringArrayVar(env string) []string {
	return strings.FieldsFunc(os.Getenv(env), func(c rune) bool {
		return c == ','
	})
}

func (o *ProjectOptions) projectOrName(ctx context.Context, dockerCli command.Cli, services ...string) (*types.Project, string, error) {
	name := o.ProjectName
	var project *types.Project
	if len(o.ConfigPaths) > 0 || o.ProjectName == "" {
		backend, err := compose.NewComposeService(dockerCli)
		if err != nil {
			return nil, "", err
		}

		p, _, err := o.ToProject(ctx, dockerCli, backend, services, skipUnsupportedAttributesWarning, cli.WithDiscardEnvFile, cli.WithoutEnvironmentResolution)
		if err != nil {
			// a service name among services can genuinely be a declared job:
			// every caller of projectOrName treats it as run-only and has
			// nothing to act on for it, so report that clearly instead of
			// either the raw "no such service" below or, worse, silently
			// falling back to the label-driven project next -- a job that
			// was never run left no container behind for that fallback to
			// find, so it would otherwise look like a successful no-op.
			if jobErr, replaced := jobTargetErr(ctx, dockerCli, o, services, err); replaced {
				return nil, "", jobErr
			}
			envProjectName := os.Getenv(ComposeProjectName)
			if envProjectName != "" {
				return nil, envProjectName, nil
			}
			return nil, "", err
		}
		project = p
		name = p.Name
	}
	return project, name, nil
}

func (o *ProjectOptions) toProjectName(ctx context.Context, dockerCli command.Cli) (string, error) {
	if o.ProjectName != "" {
		return o.ProjectName, nil
	}

	envProjectName := os.Getenv(ComposeProjectName)
	if envProjectName != "" {
		return envProjectName, nil
	}

	backend, err := compose.NewComposeService(dockerCli)
	if err != nil {
		return "", err
	}

	project, _, err := o.ToProject(ctx, dockerCli, backend, nil, skipUnsupportedAttributesWarning, cli.WithDiscardEnvFile, cli.WithoutEnvironmentResolution)
	if err != nil {
		return "", err
	}
	return project.Name, nil
}

func (o *ProjectOptions) ToModel(ctx context.Context, dockerCli command.Cli, services []string, po ...cli.ProjectOptionsFn) (map[string]any, error) {
	remotes := o.remoteLoaders(dockerCli)
	for _, r := range remotes {
		po = append(po, cli.WithResourceLoader(r))
	}

	options, err := o.toProjectOptions(po...)
	if err != nil {
		return nil, err
	}

	if o.Compatibility || utils.StringToBool(options.Environment[ComposeCompatibility]) {
		api.Separator = "_"
	}

	return options.LoadModel(ctx)
}

// ToProject loads a Compose project using the LoadProject API, then — when
// warn is warnUnsupportedAttributes — warns about any unsupported-attribute
// finding compose-go's loader reports during that load. Accepts optional
// cli.ProjectOptionsFn to control loader behavior.
func (o *ProjectOptions) ToProject(
	ctx context.Context, dockerCli command.Cli, backend api.Compose, services []string,
	warn unsupportedAttributeWarning, po ...cli.ProjectOptionsFn,
) (*types.Project, tracing.Metrics, error) {
	var metrics tracing.Metrics
	remotes := o.remoteLoaders(dockerCli)

	// Setup metrics listener to collect project data
	metricsListener := func(event string, metadata map[string]any) {
		switch event {
		case "extends":
			metrics.CountExtends++
		case "include":
			paths := metadata["path"].(types.StringList)
			for _, path := range paths {
				var isRemote bool
				for _, r := range remotes {
					if r.Accept(path) {
						isRemote = true
						break
					}
				}
				if isRemote {
					metrics.CountIncludesRemote++
				} else {
					metrics.CountIncludesLocal++
				}
			}
		}
	}

	loadOpts := api.ProjectLoadOptions{
		ProjectName:       o.ProjectName,
		ConfigPaths:       o.ConfigPaths,
		WorkingDir:        o.ProjectDir,
		EnvFiles:          o.EnvFiles,
		Profiles:          o.Profiles,
		Services:          services,
		Offline:           o.Offline,
		All:               o.All,
		Compatibility:     o.Compatibility,
		ProjectOptionsFns: po,
		LoadListeners:     []api.LoadListener{metricsListener},
		OCI:               o.ociOptions(),
	}
	if warn == warnUnsupportedAttributes {
		loadOpts.OnUnsupportedAttribute = func(findings []api.UnsupportedAttribute) {
			for _, finding := range findings {
				logrus.Warn(finding)
			}
		}
	}

	project, err := backend.LoadProject(ctx, loadOpts)
	if err != nil {
		return nil, metrics, err
	}

	return project, metrics, nil
}

func (o *ProjectOptions) remoteLoaders(dockerCli command.Cli) []loader.ResourceLoader {
	if o.remoteLoadersOverride != nil {
		return o.remoteLoadersOverride
	}
	if o.Offline {
		return nil
	}
	git := remote.NewGitRemoteLoader(dockerCli, o.Offline)
	oci := remote.NewOCIRemoteLoader(dockerCli, o.Offline, o.ociOptions())
	return []loader.ResourceLoader{git, oci}
}

// ociOptions builds the OCI loader configuration from the project options.
// Both the primary project load and the loaders returned by remoteLoaders
// must use this so the --insecure-registry flag is honored on every path
// that pulls an OCI compose artifact (e.g. the interpolation-variable
// re-load that `up` runs via ToModel). See docker/compose#13824.
func (o *ProjectOptions) ociOptions() api.OCIOptions {
	return api.OCIOptions{
		InsecureRegistries: o.insecureRegistries,
	}
}

func (o *ProjectOptions) toProjectOptions(po ...cli.ProjectOptionsFn) (*cli.ProjectOptions, error) {
	opts := []cli.ProjectOptionsFn{
		cli.WithWorkingDirectory(o.ProjectDir),
		// First apply os.Environment, always win
		cli.WithOsEnv,
	}

	if _, present := os.LookupEnv("PWD"); !present {
		if pwd, err := os.Getwd(); err != nil {
			return nil, err
		} else {
			opts = append(opts, cli.WithEnv([]string{"PWD=" + pwd}))
		}
	}

	opts = append(opts,
		// Load PWD/.env if present and no explicit --env-file has been set
		cli.WithEnvFiles(o.EnvFiles...),
		// read dot env file to populate project environment
		cli.WithDotEnv,
		// get compose file path set by COMPOSE_FILE
		cli.WithConfigFileEnv,
		// if none was selected, get default compose.yaml file from current dir or parent folder
		cli.WithDefaultConfigPath,
		// .. and then, a project directory != PWD maybe has been set so let's load .env file
		cli.WithEnvFiles(o.EnvFiles...), //nolint:gocritic // intentionally applying cli.WithEnvFiles twice.
		cli.WithDotEnv,                  //nolint:gocritic // intentionally applying cli.WithDotEnv twice.
		// eventually COMPOSE_PROFILES should have been set
		cli.WithDefaultProfiles(o.Profiles...),
		cli.WithName(o.ProjectName),
	)

	return cli.NewProjectOptions(o.ConfigPaths, append(po, opts...)...)
}

// PluginName is the name of the plugin
const PluginName = "compose"

// RunningAsStandalone detects when running as a standalone program
func RunningAsStandalone() bool {
	return len(os.Args) < 2 || os.Args[1] != metadata.MetadataSubcommandName && os.Args[1] != metadata.HookSubcommandName && os.Args[1] != PluginName
}

type BackendOptions struct {
	Options []compose.Option
}

func (o *BackendOptions) Add(option compose.Option) {
	o.Options = append(o.Options, option)
}

// RootCommand returns the compose command with its child commands
func RootCommand(dockerCli command.Cli, backendOptions *BackendOptions) *cobra.Command {
	opts := ProjectOptions{}
	var (
		ansi     string
		noAnsi   bool
		verbose  bool
		version  bool
		parallel int
		dryRun   bool
	)
	c := &cobra.Command{
		Short:            "Docker Compose",
		Long:             "Define and run multi-container applications with Docker",
		Use:              PluginName,
		TraverseChildren: true,
		// By default (no Run/RunE in parent c) for typos in subcommands, cobra displays the help of parent c but exit(0) !
		RunE: func(cmd *cobra.Command, args []string) error {
			if len(args) == 0 {
				return cmd.Help()
			}
			if version {
				return versionCommand(dockerCli).Execute()
			}
			_ = cmd.Help()
			return dockercli.StatusError{
				StatusCode: 1,
				Status:     fmt.Sprintf("unknown docker command: %q", "compose "+args[0]),
			}
		},
		PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
			err := runParentPreRun(cmd, args)
			if err != nil {
				return err
			}

			if verbose {
				logrus.SetLevel(logrus.TraceLevel)
			}

			err = setEnvWithDotEnv(opts, dockerCli)
			if err != nil {
				return err
			}
			ansi, err = resolveAnsiMode(cmd, ansi, noAnsi)
			if err != nil {
				return err
			}
			applyAnsiMode(dockerCli, ansi)

			detached, _ := cmd.Flags().GetBool("detach")
			ep, err := selectEventProcessor(dockerCli, opts.Progress, ansi, detached)
			if err != nil {
				return err
			}
			backendOptions.Add(compose.WithEventProcessor(ep))

			err = normalizeProjectOptions(&opts)
			if err != nil {
				return err
			}

			parallel, err = resolveMaxConcurrency(cmd, parallel)
			if err != nil {
				return err
			}
			if parallel > 0 {
				logrus.Debugf("Limiting max concurrency to %d jobs", parallel)
				backendOptions.Add(compose.WithMaxConcurrency(parallel))
			}

			// dry run detection
			if dryRun {
				backendOptions.Add(compose.WithDryRun)
			}
			return nil
		},
	}

	c.AddCommand(
		upCommand(&opts, dockerCli, backendOptions),
		downCommand(&opts, dockerCli, backendOptions),
		startCommand(&opts, dockerCli, backendOptions),
		restartCommand(&opts, dockerCli, backendOptions),
		stopCommand(&opts, dockerCli, backendOptions),
		psCommand(&opts, dockerCli, backendOptions),
		listCommand(dockerCli, backendOptions),
		logsCommand(&opts, dockerCli, backendOptions),
		configCommand(&opts, dockerCli),
		killCommand(&opts, dockerCli, backendOptions),
		runCommand(&opts, dockerCli, backendOptions),
		removeCommand(&opts, dockerCli, backendOptions),
		execCommand(&opts, dockerCli, backendOptions),
		attachCommand(&opts, dockerCli, backendOptions),
		exportCommand(&opts, dockerCli, backendOptions),
		commitCommand(&opts, dockerCli, backendOptions),
		pauseCommand(&opts, dockerCli, backendOptions),
		unpauseCommand(&opts, dockerCli, backendOptions),
		topCommand(&opts, dockerCli, backendOptions),
		eventsCommand(&opts, dockerCli, backendOptions),
		portCommand(&opts, dockerCli, backendOptions),
		imagesCommand(&opts, dockerCli, backendOptions),
		versionCommand(dockerCli),
		buildCommand(&opts, dockerCli, backendOptions),
		pushCommand(&opts, dockerCli, backendOptions),
		pullCommand(&opts, dockerCli, backendOptions),
		createCommand(&opts, dockerCli, backendOptions),
		copyCommand(&opts, dockerCli, backendOptions),
		waitCommand(&opts, dockerCli, backendOptions),
		scaleCommand(&opts, dockerCli, backendOptions),
		statsCommand(&opts, dockerCli),
		watchCommand(&opts, dockerCli, backendOptions),
		publishCommand(&opts, dockerCli, backendOptions),
		alphaCommand(&opts, dockerCli, backendOptions),
		bridgeCommand(&opts, dockerCli),
		volumesCommand(&opts, dockerCli, backendOptions),
	)

	c.Flags().SetInterspersed(false)
	opts.addProjectFlags(c.Flags())
	c.RegisterFlagCompletionFunc( //nolint:errcheck
		"project-name",
		completeProjectNames(dockerCli, backendOptions),
	)
	c.RegisterFlagCompletionFunc( //nolint:errcheck
		"project-directory",
		func(cmd *cobra.Command, args []string, toComplete string) ([]string, cobra.ShellCompDirective) {
			return []string{}, cobra.ShellCompDirectiveFilterDirs
		},
	)
	c.RegisterFlagCompletionFunc( //nolint:errcheck
		"file",
		func(cmd *cobra.Command, args []string, toComplete string) ([]string, cobra.ShellCompDirective) {
			return []string{"yaml", "yml"}, cobra.ShellCompDirectiveFilterFileExt
		},
	)
	c.RegisterFlagCompletionFunc( //nolint:errcheck
		"profile",
		completeProfileNames(dockerCli, &opts),
	)
	c.RegisterFlagCompletionFunc( //nolint:errcheck
		"progress",
		cobra.FixedCompletions(printerModes, cobra.ShellCompDirectiveNoFileComp),
	)

	c.Flags().StringVar(&ansi, "ansi", "auto", `Control when to print ANSI control characters ("never"|"always"|"auto")`)
	c.Flags().IntVar(&parallel, "parallel", -1, `Control max parallelism, -1 for unlimited`)
	c.Flags().BoolVarP(&version, "version", "v", false, "Show the Docker Compose version information")
	c.PersistentFlags().BoolVar(&dryRun, "dry-run", false, "Execute command in dry run mode")
	c.Flags().MarkHidden("version") //nolint:errcheck
	c.Flags().BoolVar(&noAnsi, "no-ansi", false, `Do not print ANSI control characters (DEPRECATED)`)
	c.Flags().MarkHidden("no-ansi") //nolint:errcheck
	c.Flags().BoolVar(&verbose, "verbose", false, "Show more output")
	c.Flags().MarkHidden("verbose") //nolint:errcheck
	return c
}

// runParentPreRun invokes the docker CLI root command's PersistentPreRunE,
// which cobra doesn't chain automatically.
func runParentPreRun(cmd *cobra.Command, args []string) error {
	parent := cmd.Root()
	if parent == nil {
		return nil
	}
	if prerun := parent.PersistentPreRunE; prerun != nil {
		return prerun(cmd, args)
	}
	return nil
}

// resolveAnsiMode reconciles --ansi with the deprecated --no-ansi flag and
// the COMPOSE_ANSI environment variable (flag wins over environment).
func resolveAnsiMode(cmd *cobra.Command, ansi string, noAnsi bool) (string, error) {
	if noAnsi {
		if ansi != "auto" {
			return "", errors.New(`cannot specify DEPRECATED "--no-ansi" and "--ansi". Please use only "--ansi"`)
		}
		ansi = "never"
		fmt.Fprint(os.Stderr, "option '--no-ansi' is DEPRECATED ! Please use '--ansi' instead.\n")
	}
	if v, ok := os.LookupEnv("COMPOSE_ANSI"); ok && !cmd.Flags().Changed("ansi") {
		ansi = v
	}
	return ansi, nil
}

// applyAnsiMode configures ANSI output, honoring the NO_COLOR convention
// (https://no-color.org). The progress display mode is resolved separately,
// by selectEventProcessor.
func applyAnsiMode(dockerCli command.Cli, ansi string) {
	formatter.SetANSIMode(dockerCli, ansi)

	if noColor, ok := os.LookupEnv("NO_COLOR"); ok && noColor != "" {
		display.NoColor()
		formatter.SetANSIMode(dockerCli, formatter.Never)
	}
}

// normalizeProjectOptions handles the deprecated --workdir flag and makes
// env-file paths absolute.
func normalizeProjectOptions(opts *ProjectOptions) error {
	if opts.WorkDir != "" {
		if opts.ProjectDir != "" {
			return errors.New(`cannot specify DEPRECATED "--workdir" and "--project-directory". Please use only "--project-directory" instead`)
		}
		opts.ProjectDir = opts.WorkDir
		fmt.Fprint(os.Stderr, aec.Apply("option '--workdir' is DEPRECATED at root level! Please use '--project-directory' instead.\n", aec.RedF))
	}
	for i, file := range opts.EnvFiles {
		file = composepaths.ExpandUser(file)
		if !filepath.IsAbs(file) {
			abs, err := filepath.Abs(file)
			if err != nil {
				return err
			}
			file = abs
		}
		opts.EnvFiles[i] = file
	}
	return nil
}

// resolveMaxConcurrency returns the parallelism limit: COMPOSE_PARALLEL_LIMIT
// applies unless --parallel was set explicitly on the compose command.
func resolveMaxConcurrency(cmd *cobra.Command, parallel int) (int, error) {
	composeCmd := cmd
	for composeCmd.Name() != PluginName {
		if !composeCmd.HasParent() {
			return 0, fmt.Errorf("error parsing command line, expected %q", PluginName)
		}
		composeCmd = composeCmd.Parent()
	}

	if v, ok := os.LookupEnv(ComposeParallelLimit); ok && !composeCmd.Flags().Changed("parallel") {
		i, err := strconv.Atoi(v)
		if err != nil {
			return 0, fmt.Errorf("%s must be an integer (found: %q)", ComposeParallelLimit, v)
		}
		parallel = i
	}
	return parallel, nil
}

func stdinfo(dockerCli command.Cli) io.Writer {
	if stdioToStdout {
		return dockerCli.Out()
	}
	return dockerCli.Err()
}

// selectEventProcessor picks the EventProcessor for Compose progress rendering,
// and resolves display.Mode to the mode actually rendered: every branch assigns
// it, so after command setup the global never holds ModeAuto.
//
// In auto mode we probe Err() (not Out()) because the renderer writes to stderr;
// probing stdout would force plain mode whenever stdout is redirected (e.g.
// `docker compose up | tee log`) while stderr is still a terminal.
func selectEventProcessor(dockerCli command.Cli, progress, ansi string, detached bool) (api.EventProcessor, error) {
	switch progress {
	case "", display.ModeAuto:
		switch {
		case ansi == "never":
			display.Mode = display.ModePlain
			return display.Plain(dockerCli.Err()), nil
		case dockerCli.Err().IsTerminal():
			display.Mode = display.ModeTTY
			return display.Full(dockerCli.Err(), stdinfo(dockerCli), detached), nil
		default:
			display.Mode = display.ModePlain
			return display.Plain(dockerCli.Err()), nil
		}
	case display.ModeTTY:
		if ansi == "never" {
			return nil, errors.New("can't use --progress tty while ANSI support is disabled")
		}
		display.Mode = display.ModeTTY
		return display.Full(dockerCli.Err(), stdinfo(dockerCli), detached), nil
	case display.ModePlain:
		if ansi == "always" {
			return nil, errors.New("can't use --progress plain while ANSI support is forced")
		}
		display.Mode = display.ModePlain
		return display.Plain(dockerCli.Err()), nil
	case display.ModeQuiet, "none":
		display.Mode = display.ModeQuiet
		return display.Quiet(), nil
	case display.ModeJSON:
		display.Mode = display.ModeJSON
		logrus.SetFormatter(&logrus.JSONFormatter{})
		return display.JSON(dockerCli.Err()), nil
	default:
		return nil, fmt.Errorf("unsupported --progress value %q", progress)
	}
}

func setEnvWithDotEnv(opts ProjectOptions, dockerCli command.Cli) error {
	// Check if we're using a remote config (OCI or Git)
	// If so, skip env loading as remote loaders haven't been initialized yet
	// and trying to process the path would fail
	remoteLoaders := opts.remoteLoaders(dockerCli)
	for _, path := range opts.ConfigPaths {
		for _, loader := range remoteLoaders {
			if loader.Accept(path) {
				// Remote config - skip env loading for now
				// It will be loaded later when the project is fully initialized
				return nil
			}
		}
	}

	options, err := cli.NewProjectOptions(opts.ConfigPaths,
		cli.WithWorkingDirectory(opts.ProjectDir),
		cli.WithOsEnv,
		cli.WithEnvFiles(opts.EnvFiles...),
		cli.WithDotEnv,
	)
	if err != nil {
		return err
	}
	envFromFile, err := dotenv.GetEnvFromFile(composegoutils.GetAsEqualsMap(os.Environ()), options.EnvFiles)
	if err != nil {
		return err
	}
	for k, v := range envFromFile {
		if _, ok := os.LookupEnv(k); !ok && strings.HasPrefix(k, "COMPOSE_") {
			if err := os.Setenv(k, v); err != nil {
				return err
			}
		}
	}
	return nil
}

var printerModes = []string{
	display.ModeAuto,
	display.ModeTTY,
	display.ModePlain,
	display.ModeJSON,
	display.ModeQuiet,
}
