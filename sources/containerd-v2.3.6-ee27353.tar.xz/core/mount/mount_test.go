/*
   Copyright The containerd Authors.

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/

package mount

import (
	"reflect"
	"slices"
	"testing"

	// required for `-test.root` flag not to fail
	_ "github.com/containerd/continuity/testutil"
)

func TestReadonlyMounts(t *testing.T) {
	testCases := []struct {
		desc     string
		input    []Mount
		expected []Mount
	}{
		{
			desc:     "empty slice",
			input:    []Mount{},
			expected: []Mount{},
		},
		{
			desc: "removes `upperdir` and `workdir` from overlay mounts, appends upper layer to lower",
			input: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"lowerdir=/path/to/snapshots/4/fs:/path/to/snapshots/1/fs",
					},
				},
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
					},
				},
			},
		},
		{
			desc: "removes `rw` and appends `ro` (once) to other mount types",
			input: []Mount{
				{
					Type:   "mount-without-rw",
					Source: "",
					Options: []string{
						"index=off",
						"workdir=/path/to/other/snapshots/work",
						"upperdir=/path/to/other/snapshots/2",
						"lowerdir=/path/to/other/snapshots/1",
					},
				},
				{
					Type:   "mount-with-rw",
					Source: "",
					Options: []string{
						"an-option=a-value",
						"another_opt=/another/value",
						"rw",
					},
				},
				{
					Type:   "mount-with-ro",
					Source: "",
					Options: []string{
						"an-option=a-value",
						"another_opt=/another/value",
						"ro",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "mount-without-rw",
					Source: "",
					Options: []string{
						"index=off",
						"workdir=/path/to/other/snapshots/work",
						"upperdir=/path/to/other/snapshots/2",
						"lowerdir=/path/to/other/snapshots/1",
						"ro",
					},
				},
				{
					Type:   "mount-with-rw",
					Source: "",
					Options: []string{
						"an-option=a-value",
						"another_opt=/another/value",
						"ro",
					},
				},
				{
					Type:   "mount-with-ro",
					Source: "",
					Options: []string{
						"an-option=a-value",
						"another_opt=/another/value",
						"ro",
					},
				},
			},
		},
	}

	for _, tc := range testCases {
		original := clone(tc.input)
		actual := readonlyMounts(tc.input)
		if !reflect.DeepEqual(actual, tc.expected) {
			t.Fatalf("incorrectly modified mounts: %s.\n\n Expected: %v\n\n Actual: %v", tc.desc, tc.expected, actual)
		}
		if !reflect.DeepEqual(original, tc.input) {
			t.Fatalf("modified original mounts: %s.\n\n Expected: %v\n\n Actual: %v", tc.desc, original, tc.input)
		}
		assertNoMountAlias(t, tc.desc, actual, tc.input, original)
	}
}

func TestRemoveVolatileTempMount(t *testing.T) {
	testCases := []struct {
		desc     string
		input    []Mount
		expected []Mount
	}{
		{
			desc: "remove volatile option from overlay mounts, ignore non overlay",
			input: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
						"volatile",
					},
				},
				{
					Type:   "underlay",
					Source: "underlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
						"volatile",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
				{
					Type:   "underlay",
					Source: "underlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
						"volatile",
					},
				},
			},
		},
		{
			desc: "remove fsync=volatile option from overlay mounts, ignore non overlay",
			input: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
						"fsync=volatile",
					},
				},
				{
					Type:   "underlay",
					Source: "underlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
						"fsync=volatile",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
				{
					Type:   "underlay",
					Source: "underlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
						"fsync=volatile",
					},
				},
			},
		},
		{
			desc: "return input when no volatile options on overlay",
			input: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
				{
					Type:   "underlay",
					Source: "underlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
						"volatile",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"workdir=/path/to/snapshots/4/work",
						"upperdir=/path/to/snapshots/4/fs",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
				{
					Type:   "underlay",
					Source: "underlay",
					Options: []string{
						"index=on",
						"lowerdir=/another/path/to/snapshots/2/fs",
						"volatile",
					},
				},
			},
		},
		{
			desc: "remove multiple volatile options from overlay mounts",
			input: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"volatile",
						"fsync=volatile",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
			},
		},
	}

	for _, tc := range testCases {
		original := clone(tc.input)
		actual := RemoveVolatileOption(tc.input)
		if !reflect.DeepEqual(actual, tc.expected) {
			t.Fatalf("incorrectly modified mounts: %s.\n\n Expected: %v\n\n, Actual: %v", tc.desc, tc.expected, actual)
		}
		if !reflect.DeepEqual(original, tc.input) {
			t.Fatalf("modified original mounts: %s.\n\n Expected: %v\n\n, Actual: %v", tc.desc, original, tc.input)
		}
		if !reflect.DeepEqual(actual, original) {
			assertNoMountAlias(t, tc.desc, actual, tc.input, original)
		}
	}
}

func TestRemoveIDMapOption(t *testing.T) {
	testCases := []struct {
		desc     string
		input    []Mount
		expected []Mount
	}{
		{
			desc: "remove idmap options",
			input: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"uidmap=0:1000:1",
						"gidmap=0:1000:1",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "overlay",
					Source: "overlay",
					Options: []string{
						"index=off",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
			},
		},
		{
			desc: "remove idmapping options",
			input: []Mount{
				{
					Type:   "fuse-overlayfs",
					Source: "overlay",
					Options: []string{
						"index=off",
						"uidmapping=0:1000:1",
						"gidmapping=0:1000:1",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "fuse-overlayfs",
					Source: "overlay",
					Options: []string{
						"index=off",
						"lowerdir=/path/to/snapshots/1/fs",
					},
				},
			},
		},
		{
			desc: "return input when no idmap options",
			input: []Mount{
				{
					Type:   "bind",
					Source: "/path/to/source",
					Options: []string{
						"rbind",
						"ro",
					},
				},
			},
			expected: []Mount{
				{
					Type:   "bind",
					Source: "/path/to/source",
					Options: []string{
						"rbind",
						"ro",
					},
				},
			},
		},
	}

	for _, tc := range testCases {
		original := clone(tc.input)
		actual := RemoveIDMapOption(tc.input)
		if !reflect.DeepEqual(actual, tc.expected) {
			t.Fatalf("incorrectly modified mounts: %s.\n\n Expected: %v\n\n Actual: %v", tc.desc, tc.expected, actual)
		}
		if !reflect.DeepEqual(original, tc.input) {
			t.Fatalf("modified original mounts: %s.\n\n Expected: %v\n\n Actual: %v", tc.desc, original, tc.input)
		}
		if !reflect.DeepEqual(actual, original) {
			assertNoMountAlias(t, tc.desc, actual, tc.input, original)
		}
	}
}

func assertNoMountAlias(t *testing.T, desc string, actual, input, original []Mount) {
	t.Helper()
	if len(actual) == 0 {
		return
	}
	actual[0].Source = "changed"
	if len(actual[0].Options) > 0 {
		actual[0].Options[0] = "changed"
	}
	if !reflect.DeepEqual(original, input) {
		t.Fatalf("returned mounts alias original mounts: %s.\n\n Expected: %v\n\n Actual: %v", desc, original, input)
	}
}

func clone(mounts []Mount) []Mount {
	out := slices.Clone(mounts)
	for i, m := range mounts {
		out[i].Options = slices.Clone(m.Options)
	}
	return out
}
